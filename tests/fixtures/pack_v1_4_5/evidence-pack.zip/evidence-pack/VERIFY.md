# How to verify this evidence pack

You do not need to trust the report: re-check everything from the files.

```bash
pip install 'perathos[anchor]'
perathos evidence verify <this folder or .zip> --verify-key 97e5968c36625a65e75a3c9c1b14f04023924a18daf0061c0411669f49732204
```

This checks that every file matches the signed MANIFEST.json, re-verifies the
receipt chain and every checkpoint signature, and re-verifies each RFC 3161
timestamp in `anchors.jsonl` against the timestamp authority's root.

If the pack has an `approvals/` folder (a person approved an action through
Perathos Gate), also pass `--gate-key <Gate server key>` and
`--approver-key <approver passkey public key>` (repeatable). Without them the
output says `Gate key UNCONFIRMED` or `approvers NOT PINNED`: the approvals are
then internally consistent, but could have been signed by any key pair.

Confirm the signer key (and the Gate and approver keys) with the session's
owner through a separate channel before relying on them. Receipt format: https://github.com/perathos-protocol/perathos/blob/main/docs/specs/RECEIPT_V1.md
