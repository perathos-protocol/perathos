# Agent session evidence: pocketos-replay

**Verification: VALID**

- Recorded: 2026-11-04T08:19:04.700884Z to 2026-11-04T08:19:08.217162Z (local clock)
- Tool calls: 4, blocked by the guard: 2
- Sealed through receipt 8 by 2 signed checkpoint(s)
- Signer key: d53f11ff38959d472a2e619b346340b44a79866fb8650d96f22ada467f524707
- Independent timestamps: 2 (through receipt 8, 2026-11-04T08:19:09Z)
- Model (self-reported): unknown

## Destructive calls blocked

- receipt 3 at 2026-11-04T08:19:05.192047Z: Bash matched `paas.railway`
- receipt 4 at 2026-11-04T08:19:05.431384Z: Bash matched `guard.self-authorize`

## Destructive calls allowed under a signed safety check

- receipt 6 at 2026-11-04T08:19:07.697718Z: `paas.railway` allowed; check `python check_backup.py offsite/prod-backup.db` (scope `pg-data`, signed 2026-11-04T08:19:07Z, expires 2026-11-04T08:49:07Z)

## Tools used

- Bash: 4

## What this does not show

- Shows which key sealed the record, not which model ran (the model name is self-reported).
- Event times come from the local clock; only anchored checkpoints have an independent time.
- Tool arguments and outputs are not included, only their SHA-256 hashes.
- A gap in recording (hooks switched off) is not visible in the log.
- The guard matches command patterns; it is a safeguard against accidents, not a sandbox.

Re-check independently: see VERIFY.md.
