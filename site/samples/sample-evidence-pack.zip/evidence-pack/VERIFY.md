# How to verify this evidence pack

You do not need to trust the report: re-check everything from the files.

```bash
pip install 'perathos[anchor]'
perathos evidence verify <this folder or .zip> --verify-key d53f11ff38959d472a2e619b346340b44a79866fb8650d96f22ada467f524707
```

This checks that every file matches the signed MANIFEST.json, re-verifies the
receipt chain and every checkpoint signature, and re-verifies each RFC 3161
timestamp in `anchors.jsonl` against the timestamp authority's root.

Confirm the signer key with the session's owner through a separate channel
before relying on it. Receipt format: https://github.com/perathos-protocol/perathos/blob/main/docs/specs/RECEIPT_V1.md
